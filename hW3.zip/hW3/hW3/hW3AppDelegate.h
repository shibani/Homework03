//
//  hW3AppDelegate.h
//  hW3
//
//  Created by Shibani Mookerjee on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class View;
@interface hW3AppDelegate : NSObject <UIApplicationDelegate> {
    
    View *view;
    UIWindow *_window;

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
