//
//  TileView.m
//  hW3
//
//  Created by Shibani Mookerjee on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"
#import "TileView.h"
#import "FrontView.h"
#import "BackView.h"

@implementation TileView


- (id)initWithFrame:(CGRect)frame
{
    
    return self;
}

- (CGPoint) center {
	CGFloat margin = 2;	//in pixels between pieces
	CGFloat half = (3 - 1) / 2;
	CGSize size = self.bounds.size;
	
	CGFloat x = (size.width  + margin) * (col - half);
	CGFloat y = (size.height + margin) * (row - half);
	
	return CGPointMake(x, y);
}


- (id) initWithView: (View *) v row: (NSUInteger) r col: (NSUInteger) c {
    NSString *filename = [NSString stringWithFormat: @"/images/thumbs/%u%u.png", r, c];
    UIImage *image = [UIImage imageNamed: filename];
    if (image == nil) {
        NSLog(@"could not find file %u%u.png", r, c);
        return nil;
    }
    
    self = [super initWithImage:image];
    if (self) {
        // Initialization code
        view = v;
        row = r;
        col = c;
        self.center = [self center];
        self.transform = CGAffineTransformMakeScale(0.9, 0.9);
        self.userInteractionEnabled = YES;	
    }
    return self;
}


- (void) oneTap {
    
    tapCount = 1;
   
    NSString *imageFileName = [NSString stringWithFormat: @"/images/large/large%u%u.png", row, col];
    UIImage *image = [UIImage imageNamed:imageFileName];
    
    NSLog(@"imageFileName: the tile that was touched was %@", imageFileName);
    
    NSString *textFileName = [NSString stringWithFormat: @"/images/text/text%u%u.png", row, col];
    UIImage *textImage = [UIImage imageNamed:textFileName];
    
    frontView = [[FrontView alloc] initWithImage: image];
    backView = [[FrontView alloc] initWithImage:textImage];
    
    [view addSubview: backView];
    [view addSubview: frontView];

}

- (void) doubleTap {
   
    tapCount = 2;
    
    NSString *textFileName = [NSString stringWithFormat: @"/images/text/text%u%u.png", row, col];
    UIImage *textImage = [UIImage imageNamed:textFileName];
    
    backView = [[BackView alloc] initWithImage:textImage];
    [view addSubview: backView];
    
    [backView setNeedsDisplay];
       
}


 - (void)touchesEnded: (NSSet *)touches withEvent: (UIEvent *)event { 
     
 
     UITouch *t = [touches anyObject];
 
     if (t.tapCount == 1) {
         
     [self performSelector: @selector(oneTap) withObject: nil
     afterDelay: 0.5];
       
     } else if (t.tapCount == 2) {
         
     [self performSelector: @selector(doubleTap) withObject: nil
     afterDelay: 0.5];
            }
  }
 
 
 - (void)touchesBegan: (NSSet *)touches withEvent: (UIEvent *)event {
 
     UITouch *t = [touches anyObject];
     
     if (t.tapCount == 2) {
     [NSObject cancelPreviousPerformRequestsWithTarget: self];
            }
     } 

/*
- (void)drawRect:(CGRect)rect
{

}
 */

- (void)dealloc
{
    [backView release];
    [frontView release];
    [set release];
    [view release];
    [super dealloc];
}

@end

