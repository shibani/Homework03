//
//  View.m
//  hW3
//
//  Created by Shibani Mookerjee on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"
#import "TileView.h"

@implementation View

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];
        
        CGSize s = self.bounds.size;
		self.bounds = CGRectMake(
                                 -s.width / 2,
                                 -s.height / 2,
                                 s.width,
                                 s.height
                                 );
        
        set = [NSArray arrayWithObjects:
               [[TileView alloc] initWithView: self row: 0 col: 0],
               [[TileView alloc] initWithView: self row: 0 col: 1],
               [[TileView alloc] initWithView: self row: 0 col: 2],
               
               [[TileView alloc] initWithView: self row: 1 col: 0],
               [[TileView alloc] initWithView: self row: 1 col: 1],
               [[TileView alloc] initWithView: self row: 1 col: 2],
			   
               [[TileView alloc] initWithView: self row: 2 col: 0],
               [[TileView alloc] initWithView: self row: 2 col: 1],
               [[TileView alloc] initWithView: self row: 2 col: 2],
               nil
               ];
		[set retain];
        
        
        for (TileView *p in set) {
            
            [self addSubview: p];
     
		}
        
    } return self;
}


/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void)dealloc
{
   
    for (TileView *p in set){
        [p release];
    }
    
    [set release];
    [super dealloc];
}

@end
