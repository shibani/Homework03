//
//  main.m
//  hW3
//
//  Created by Shibani Mookerjee on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    
    int retVal = UIApplicationMain(argc, argv, nil, @"hW3AppDelegate");
    [pool release];
    return retVal;
}
