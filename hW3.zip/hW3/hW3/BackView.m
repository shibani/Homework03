//
//  BackView.m
//  hW3
//
//  Created by Shibani Mookerjee on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import "BackView.h"
#import "TileView.h"

@implementation BackView

    CGPoint current0;
    CGPoint current1;

    CGPoint previous0;
    CGPoint previous1;

- (id) initWithImage: image{
    
    self = [super initWithImage:image];
    if (self) {
        //CGPoint p = CGPointMake (self.bounds.size.width/2, self.bounds.size.height/2);
        self.center = CGPointZero;
        self.userInteractionEnabled = YES;
    

    } return self;
}

- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
        
         NSLog(@"# of touches moved touches is %u", touches.count);
    
        if (touches.count == 2) {
        
        current0 = [[a objectAtIndex: 0] locationInView: self];
        current1 = [[a objectAtIndex: 1] locationInView: self];
    
        CGFloat dx = current0.x - current1.x;
        CGFloat dy = current0.y - current1.y;
        CGFloat currentDistance = hypotf(dx, dy);
        
        
        self.transform = CGAffineTransformMakeScale(currentDistance / 50, currentDistance / 50);
        
    }  
    
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    NSLog(@"# of touches moved touches is %u", touches.count);
    
    [self performSelector: @selector(home) withObject: nil
               afterDelay: 2.0];
    
    }  

    
- (void) home {
    
    [self removeFromSuperview];
    
}
    
    
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc
{
    [a release];
    [super dealloc];
}

@end
