//
//  frontView.m
//  hW3
//
//  Created by Shibani Mookerjee on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FrontView.h"

@implementation FrontView


- (id) initWithImage: image{
    
    self = [super initWithImage:image];
    if (self) {
        self.center = CGPointZero;
        self.userInteractionEnabled = YES;
            
    } return self;
}

- (void) swipe {
    
    [UIView transitionFromView: self 
                        toView: backView
                      duration: 2
                       options: UIViewAnimationOptionTransitionFlipFromLeft
                    completion: NULL
     ];
    
}


//perform this after 0.2 seconds to see if it is a pinch or a swipe
- (void) touchesMoved: (NSSet *) touches withEvent: (UIEvent *) event {

    
    if (touches.count < 2) {
   
        [self performSelector: @selector(swipe) withObject: nil
                   afterDelay: 0.2];
        
    } 
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc
{
    [backView release];
    [views release];
    [super dealloc];
}

@end
