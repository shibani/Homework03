//
//  TileView.h
//  hW3
//
//  Created by Shibani Mookerjee on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@class View;
@interface TileView : UIImageView {
        
        View *view;
        NSUInteger row;
        NSUInteger col;
        NSUInteger tapCount;
        NSArray *set;
        UIImageView *frontView;
        UIImageView *backView;
    
    }
    
    
- (id) initWithView:(View *) v row: (NSUInteger) r col: (NSUInteger) c;
    
//- (id) initWithFrame:(CGRect)frame text: (NSString *) t font: (UIFont *) f; 

@end
