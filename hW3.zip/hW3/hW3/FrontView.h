//
//  frontView.h
//  hW3
//
//  Created by Shibani Mookerjee on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FrontView : UIImageView {
    

    NSArray *views;
    NSUInteger index;
    UIImageView *backView;
    
}

- (id) initWithImage:(UIImage *)image;



@end
