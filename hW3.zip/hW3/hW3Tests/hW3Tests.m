//
//  hW3Tests.m
//  hW3Tests
//
//  Created by Shibani Mookerjee on 7/12/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "hW3Tests.h"


@implementation hW3Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in hW3Tests");
}

@end
